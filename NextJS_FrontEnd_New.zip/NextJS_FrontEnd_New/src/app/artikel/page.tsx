"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import useSWR from "swr";
import { fetcher } from "@/lib/fetcher";
import { ContentLayout } from "@/components/panel/content-layout";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ArrowRight, Eye } from "lucide-react";
import { format } from "date-fns";

export default function ArtikelPage() {
  const { data, isLoading } = useSWR("/api/blog", fetcher);
  const [visibleCount, setVisibleCount] = useState(6);

  if (isLoading) {
    return (
      <ContentLayout title="Artikel">
        <div className="flex h-[60vh] items-center justify-center">
          <LoadingSpinner size={40} />
        </div>
      </ContentLayout>
    );
  }

  const blogs = data?.blogs ?? [];
  const visibleBlogs = blogs.slice(0, visibleCount);
  const isMore = visibleCount < blogs.length;

  return (
    <ContentLayout title="Artikel">
      <section className="pb-16">
        {/* HEADER */}
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <Badge variant="secondary" className="mb-4">
            Artikel & Berita
          </Badge>
          <h1 className="mb-3 text-3xl font-bold tracking-tight md:text-4xl">
            Update Terbaru & Insight
          </h1>
          <p className="text-muted-foreground">
            Berita, promo, dan panduan terbaru seputar game dan top up digital.
          </p>
        </div>

        {/* GRID ARTIKEL */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {visibleBlogs.map((post: any) => (
            <Card
              key={post.id}
              className="flex flex-col overflow-hidden pt-0 transition-shadow hover:shadow-md"
            >
              {/* IMAGE */}
              <Link href={`/artikel/${post.slug}`}>
                <div className="relative aspect-video w-full overflow-hidden">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    className="object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
              </Link>

              {/* HEADER */}
              <CardHeader className="pb-2">
                <h3 className="line-clamp-2 text-lg font-semibold">
                  <Link href={`/artikel/${post.slug}`} className="hover:underline">
                    {post.title}
                  </Link>
                </h3>
              </CardHeader>

              {/* CONTENT */}
              <CardContent className="flex-1 pt-0">
                <p className="line-clamp-3 text-sm text-muted-foreground">
                  {post.summary ||
                    post.excerpt ||
                    "Baca artikel ini untuk mengetahui informasi selengkapnya."}
                </p>
              </CardContent>

              {/* FOOTER */}
              <CardFooter className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <span>{format(new Date(post.published_at), "dd MMM yyyy")}</span>
                  <span className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    {post.views}
                  </span>
                </div>

                <Link
                  href={`/artikel/${post.slug}`}
                  className="flex items-center gap-1 font-medium text-my-color hover:underline"
                >
                  Baca
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* LOAD MORE */}
        {isMore && (
          <div className="mt-10 flex justify-center">
            <Button variant="outline" onClick={() => setVisibleCount((v) => v + 6)}>
              Muat Lebih Banyak
            </Button>
          </div>
        )}
      </section>
    </ContentLayout>
  );
}