"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useMemo, useState } from "react";
import { ExternalLink, CheckCircle2, XCircle } from "lucide-react";

import { ContentLayout } from "@/components/panel/content-layout";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

const num = (v: any) => {
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
};

const fmtRupiah = (v: any) => {
  const n = Math.max(0, Math.floor(num(v)));
  if (!n) return "-";
  return `Rp ${n.toLocaleString("id-ID")}`;
};

export default function PriceListPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [selectedGameId, setSelectedGameId] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  useEffect(() => {
    let alive = true;

    setLoading(true);
    setErr(null);

    fetch("/api/price-list", {
      method: "GET",
      headers: { Accept: "application/json" },
      cache: "no-store",
    })
      .then(async (res) => {
        const ct = (res.headers.get("content-type") || "").toLowerCase();
        const isJson = ct.includes("application/json");
        const json = isJson ? await res.json().catch(() => ({})) : null;

        if (!res.ok) {
          const msg = json?.message || `Gagal mengambil data. Status: ${res.status}`;
          throw new Error(msg);
        }
        if (!isJson) throw new Error("Response tidak valid (bukan JSON).");

        return json;
      })
      .then((json) => {
        if (!alive) return;
        setData(json);
      })
      .catch((e: any) => {
        if (!alive) return;
        setErr(String(e?.message || e));
        setData(null);
      })
      .finally(() => {
        if (!alive) return;
        setLoading(false);
      });

    return () => {
      alive = false;
    };
  }, []);

  const gameList = useMemo(() => {
    if (!data?.success) return [];
    return Array.isArray(data.data) ? data.data : [];
  }, [data]);

  useEffect(() => {
    if (gameList.length && !selectedGameId) {
      setSelectedGameId(String(gameList[0].id));
    }
  }, [gameList, selectedGameId]);

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedGameId]);

  const selectedGame = useMemo(() => {
    return gameList.find((g: any) => String(g.id) === String(selectedGameId)) || null;
  }, [selectedGameId, gameList]);

  const totalPages = useMemo(() => {
    const total = selectedGame?.products?.length ?? 0;
    return Math.max(1, Math.ceil(total / itemsPerPage));
  }, [selectedGame, itemsPerPage]);

  const paginatedProducts = useMemo(() => {
    const products = Array.isArray(selectedGame?.products) ? selectedGame.products : [];
    const start = (currentPage - 1) * itemsPerPage;
    return products.slice(start, start + itemsPerPage);
  }, [selectedGame, currentPage, itemsPerPage]);

  return (
    <ContentLayout title="Daftar Produk">
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-semibold">Daftar Harga Produk</h2>
          <p className="text-sm text-muted-foreground">
            Pilih game, lalu order produk yang kamu inginkan.
          </p>
        </div>

        {err ? (
          <div className="w-full max-w-4xl mx-auto rounded-md border bg-background p-4 text-sm">
            <div className="font-semibold text-red-600">Gagal memuat daftar harga</div>
            <div className="mt-1 text-muted-foreground">{err}</div>
            <div className="mt-3">
              <button
                className="rounded-lg bg-my-color px-3 py-2 text-xs font-semibold text-white"
                onClick={() => location.reload()}
              >
                Coba Lagi
              </button>
            </div>
          </div>
        ) : null}

        <div className="w-full max-w-md mx-auto">
          {loading ? (
            <Skeleton className="h-10 w-full" />
          ) : (
            <Select value={selectedGameId} onValueChange={setSelectedGameId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Pilih Game" />
              </SelectTrigger>
              <SelectContent>
                {gameList.map((game: any) => (
                  <SelectItem key={game.id} value={String(game.id)}>
                    {game.game_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {loading ? (
          <div className="w-full max-w-4xl mx-auto rounded-md border bg-background p-4">
            <Skeleton className="h-10 w-full" />
            <div className="mt-3 space-y-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          </div>
        ) : selectedGame ? (
          <div className="space-y-4">
            <div className="w-full max-w-4xl mx-auto rounded-md border bg-background">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[260px]">Produk</TableHead>
                      <TableHead className="text-left whitespace-nowrap">Basic</TableHead>
                      <TableHead className="text-left whitespace-nowrap">Gold</TableHead>
                      <TableHead className="text-left whitespace-nowrap">Platinum</TableHead>
                      <TableHead className="text-left whitespace-nowrap">Status</TableHead>
                      <TableHead className="text-center whitespace-nowrap">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>

                  <TableBody>
                    {paginatedProducts.map((product: any) => {
                      const isActive = product.status === 1;

                      const href = selectedGame?.slug
                        ? `/order/${selectedGame.slug}?product_id=${encodeURIComponent(String(product.id))}`
                        : "#";

                      return (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {product.images ? (
                                <div className="relative h-9 w-9 shrink-0">
                                  <Image
                                    src={product.images}
                                    alt={product.title}
                                    fill
                                    sizes="36px"
                                    className="object-contain"
                                  />
                                </div>
                              ) : (
                                <div className="h-9 w-9 shrink-0 bg-muted" />
                              )}

                              <div className="min-w-0">
                                <div className="font-medium leading-snug">
                                  {product.title}
                                </div>
                              </div>
                            </div>
                          </TableCell>

                          <TableCell className="text-left whitespace-nowrap tabular-nums">
                            {fmtRupiah(product.selling_price)}
                          </TableCell>

                          <TableCell className="text-left whitespace-nowrap tabular-nums text-yellow-600 font-medium">
                            {fmtRupiah(product.selling_price_gold)}
                          </TableCell>

                          <TableCell className="text-left whitespace-nowrap tabular-nums text-indigo-600 font-medium">
                            {fmtRupiah(product.selling_price_platinum)}
                          </TableCell>

                          <TableCell className="text-left whitespace-nowrap">
                            {isActive ? (
                              <span className="inline-flex items-center gap-1 text-green-600 font-medium">
                                <CheckCircle2 className="h-4 w-4" />
                                Aktif
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-red-600 font-medium">
                                <XCircle className="h-4 w-4" />
                                Nonaktif
                              </span>
                            )}
                          </TableCell>

                          <TableCell className="text-center whitespace-nowrap">
                            {selectedGame?.slug ? (
                              <Link
                                href={href}
                                className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                              >
                                Order
                                <ExternalLink className="h-4 w-4" />
                              </Link>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="flex items-center justify-between w-full max-w-4xl mx-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                Sebelumnya
              </Button>

              <span className="text-sm text-muted-foreground">
                Halaman {currentPage} dari {totalPages}
              </span>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                Selanjutnya
              </Button>
            </div>
          </div>
        ) : (
          <p className="text-center text-muted-foreground">
            Pilih game untuk melihat produk.
          </p>
        )}
      </div>
    </ContentLayout>
  );
}