import "./globals.css";
import "./embla.css";
import "./custom.css";
import { GeistSans } from "geist/font/sans";
import { SettingsProvider } from "@/context/settings-context";
import PanelLayout from "@/components/panel/panel-layout";
import { ThemeProvider } from "@/components/providers/theme-provider";
import { ProgressBar } from "@/components/progress-bar/progress-bar";
import { Toaster } from "sonner";
import { Metadata } from "next";

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3100";
  const metadataBase = new URL(siteUrl);

  try {
    const res = await fetch(`${siteUrl}/api/settings`, { next: { revalidate: 3600 } });
    if (!res.ok) throw new Error("Failed to fetch settings");

    const settings = await res.json();

    const baseAssetUrl =
      process.env.NEXT_PRIVATE_API_URL || process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8003";
    const getFullUrl = (path?: string) => (path?.startsWith("http") ? path : `${baseAssetUrl}/storage/${path}`);

    const rawFavicon = settings.data?.["general.favicon"];
    const rawLogo = settings.data?.["general.logo"];

    const favicon = Array.isArray(rawFavicon) ? rawFavicon[0] : rawFavicon;
    const logo = Array.isArray(rawLogo) ? rawLogo[0] : rawLogo;

    return {
      metadataBase,
      title: settings.data?.["seo.title"] || settings.data?.["general.title"] || "Default Title",
      description: settings.data?.["seo.description"] || "Default description",
      keywords: settings.data?.["seo.keywords"] || "default, keywords",
      icons: { icon: favicon || "/favicon.ico" },
      openGraph: {
        title: settings.data?.["seo.title"] || "Default Title",
        description: settings.data?.["seo.description"] || "Default description",
        url: metadataBase.origin,
        images: [
          {
            url: getFullUrl(logo) || "/default-og-image.jpg",
            width: 1200,
            height: 630,
            alt: settings.data?.["seo.title"] || "Default Title",
          },
        ],
        type: "website",
      },
      twitter: {
        card: "summary_large_image",
        title: settings.data?.["seo.title"] || "Default Title",
        description: settings.data?.["seo.description"] || "Default description",
        images: [getFullUrl(logo) || "/default-og-image.jpg"],
      },
    };
  } catch (error) {
    console.error("Failed to fetch settings:", error);

    return {
      metadataBase,
      title: "Default Title",
      description: "Default Description",
      keywords: "topup game, beli diamond, game online",
      icons: { icon: "/favicon.ico" },
      openGraph: {
        title: "Top Up Game",
        description: "Top Up Game Murah & Terpercaya",
        url: metadataBase.origin,
        images: [
          {
            url: "/default-og-image.jpg",
            width: 1200,
            height: 630,
            alt: "Top Up Game",
          },
        ],
        type: "website",
      },
      twitter: {
        card: "summary_large_image",
        title: "Top Up Game",
        description: "Top Up Game Murah & Terpercaya",
        images: ["/default-og-image.jpg"],
      },
    };
  }
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={GeistSans.className}>
        <ProgressBar className="fixed top-0 h-0.5 bg-indigo-600 z-30">
          <Toaster position="top-center" />
          <ThemeProvider attribute="class" defaultTheme="system">
            <SettingsProvider>
              <PanelLayout>{children}</PanelLayout>
            </SettingsProvider>
          </ThemeProvider>
        </ProgressBar>
      </body>
    </html>
  );
}