import {
  Home,
  ReceiptText,
  Newspaper,
  User,
  Headset,
  LucideIcon,
  BadgeDollarSign
} from "lucide-react";

type Submenu = {
  href: string;
  label: string;
  active?: boolean;
};

type Menu = {
  href: string;
  label: string;
  active?: boolean;
  icon: LucideIcon;
  submenus?: Submenu[];
};

type Group = {
  groupLabel: string;
  menus: Menu[];
};

export function getMenuList(pathname: string, isLoggedIn: boolean): Group[] {
  const menu: Group[] = [
    {
      groupLabel: "Menu",
      menus: [
        {
          href: "/",
          label: "Home",
          icon: Home,
          submenus: []
        },
        {
          href: "/invoices",
          label: "Cek Invoice",
          icon: ReceiptText
        },
        {
          href: "/price-list",
          label: "Daftar Harga",
          icon: BadgeDollarSign
        },
        {
          href: "/artikel",
          label: "Artikel",
          icon: Newspaper
        },
        {
          href: "/contact",
          label: "Hubungi Kami",
          icon: Headset
        },
      ]
    }
  ];

  if (isLoggedIn) {
    menu.push({
      groupLabel: "User",
      menus: [
        {
          href: "/dashboard",
          label: "Profile",
          icon: User,
          submenus: []
        },
      ]
    });
  }

  return menu;
}