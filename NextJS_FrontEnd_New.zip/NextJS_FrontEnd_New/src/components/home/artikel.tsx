"use client";

import { useState } from "react";
import Image from "next/image";
import useSWR from "swr";
import { fetcher } from "@/lib/fetcher";
import Link from "next/link";
import clsx from "clsx";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

export default function Artikel() {
  const { data, error, isLoading, mutate } = useSWR("/api/blog", fetcher);
  const [visibleCount] = useState(6);

  const blogs = Array.isArray(data?.blogs) ? data.blogs : [];
  const visibleBlogs = blogs.slice(0, visibleCount);

  if (isLoading) {
    return (
      <div className="pb-12 -mx-4">
        <div className="mb-6 px-4">
          <Skeleton className="h-5 w-56 mb-2" />
          <Skeleton className="h-4 w-full max-w-2xl" />
          <Skeleton className="h-4 w-full max-w-xl mt-2" />
        </div>

        <div className="overflow-x-auto hide-scrollbar px-4">
          <div className="flex gap-4 w-[calc(100vw-2rem)] sm:w-auto py-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className={clsx(
                  "min-w-[75%] sm:min-w-[300px] max-w-sm rounded-2xl overflow-hidden bg-muted shadow-md",
                  i === 1 && "mr-10 sm:mr-0"
                )}
              >
                <Skeleton className="w-full aspect-[4/3]" />
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 px-4">
          <Skeleton className="h-9 w-40 rounded-full" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pb-12 -mx-4">
        <div className="px-4">
          <div className="rounded-xl border border-border bg-muted/30 p-6">
            <div className="text-sm font-medium">Gagal memuat artikel</div>
            <div className="mt-1 text-xs text-muted-foreground">
              {(error as Error)?.message ?? "Terjadi kesalahan."}
            </div>
            <div className="mt-4">
              <Button type="button" variant="outline" onClick={() => mutate()}>
                Coba Lagi
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!blogs.length) return null;

  return (
    <div className="pb-12 -mx-4">
      <div className="mb-6 px-4">
        <h2 className="text-md sm:text-xl font-bold mb-2">ARTIKEL TERBARU & BERITA GAME</h2>
        <p className="text-xs sm:text-base">
          Dapatkan informasi terbaru seputar dunia game! Temukan panduan lengkap untuk meningkatkan pengalaman bermain,
          serta berita terkini mengenai promo, update top-up, dan komunitas gamer.
        </p>
      </div>

      <div className="overflow-x-auto hide-scrollbar px-4">
        <div className="flex gap-4 w-[calc(100vw-2rem)] sm:w-auto py-3">
          {visibleBlogs.map((post: any, i: number) => (
            <Link
              key={post.id}
              href={`/artikel/${post.slug}`}
              className={clsx(
                "min-w-[75%] sm:min-w-[300px] max-w-sm rounded-2xl overflow-hidden bg-muted shadow-md hover:shadow-lg transition-shadow duration-300 ease-in-out hover:ring-my-color hover:ring-offset-2 hover:ring-offset-background hover:ring-[3px]",
                i === 1 && "mr-10 sm:mr-0"
              )}
            >
              <div className="relative aspect-[4/3] w-full">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 640px) 75vw, 300px"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent p-4 flex items-end">
                  <h2 className="text-white font-semibold text-base sm:text-lg line-clamp-2">{post.title}</h2>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <div className="mt-4 px-4">
        <Link
          href="/artikel"
          className="inline-block bg-muted px-6 py-2 rounded-full text-sm font-medium shadow hover:shadow-lg transition-all"
        >
          Lihat Semua Artikel
        </Link>
      </div>
    </div>
  );
}