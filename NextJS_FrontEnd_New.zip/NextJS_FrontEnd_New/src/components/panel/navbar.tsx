"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";

import { useSettings } from "@/context/settings-context";
import { ModeToggle } from "@/components/mode-toggle";
import { UserNav } from "@/components/panel/user-nav";
import { SheetMenu } from "@/components/panel/sheet-menu";
import { Search } from "@/components/panel/search";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { getMenuList } from "@/lib/menu-list";
import { cn } from "@/lib/utils";

export function Navbar() {
  interface Settings {
    data: {
      ["general.logo"]?: string;
      ["general.title"]?: string;
    };
  }

  const { data: session } = useSession();
  const isLoggedIn = !!session;

  const settings = useSettings() as unknown as Settings | null;
  const logoUrl = settings?.data?.["general.logo"];
  const logoTitle = settings?.data?.["general.title"];
  const pathname = usePathname();
  const menuList = getMenuList(pathname, isLoggedIn);

  return (
    <header className="sticky top-0 z-10 w-full bg-background/95 shadow backdrop-blur supports-[backdrop-filter]:bg-background/60 dark:shadow-secondary">
      <div className="mx-4 sm:mx-8 flex h-16 items-center">
        <div className="flex items-center space-x-4 lg:space-x-0">
          <SheetMenu />
          <Link href="/">
            {logoUrl ? (
              <Image
                src={logoUrl}
                alt={logoTitle || "logo"}
                width={120}
                height={40}
                priority
                className="w-32 h-auto"
              />
            ) : (
              <Skeleton className="w-32 h-10 sm:hidden" />
            )}
          </Link>
        </div>

        <div className="flex flex-1 items-center justify-end gap-2">
          <Search />
          <div className="hidden lg:block">
            {!isLoggedIn && (
              <div className="flex items-center gap-2">
                <Button asChild variant="outline" size="sm" className="shadow-none">
                  <Link href="/signin">Masuk</Link>
                </Button>
                <Button asChild size="sm" className="shadow-none">
                  <Link href="/signup">Daftar</Link>
                </Button>
              </div>
            )}
          </div>
          <ModeToggle />
          {session && <UserNav />}
        </div>
      </div>

      <nav className="mx-4 sm:mx-8 border-t border-border pt-2 pb-3 overflow-x-auto hidden md:flex items-center">
        <ul className="flex items-center gap-3">
          {menuList.map(({ menus }) =>
            menus.map(({ href, label, icon: Icon, active }) => (
              <li key={href}>
                <Link href={href}>
                  <Button
                    variant={active ? "secondary" : "ghost"}
                    className={cn(
                      "gap-2",
                      pathname === href || pathname.startsWith(`${href}/`) ? "text-primary" : ""
                    )}
                  >
                    <Icon size={16} />
                    <span className="text-sm">{label}</span>
                  </Button>
                </Link>
              </li>
            ))
          )}
        </ul>
      </nav>
    </header>
  );
}