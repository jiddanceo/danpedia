'use client'

import { Clipboard } from "lucide-react"
import Image from "next/image"
import { Transaction } from "@/types"
import QRCode from "react-qr-code"
import { useEffect, useMemo, useRef, useState } from "react"
import { Button } from "@/components/ui/button"

interface InvoicePaymentMethodProps {
  order: Transaction
  handleCopyPayCode: () => void
  handleCopyOrderId: () => void
  handleCopySn: () => void
  getBackgroundPayStatusColor: () => string
  getBackgroundBuyStatusColor: () => string
  getBuyStatusMessage: () => string
}

const QRIS_IMAGE_METHODS = ["QRIS", "QRISC", "QRIS2", "11", "17", "20"]
const QRIS_STRING_METHODS = ["SP", "NQ", "DQ", "GQ", "SQ", "SMPQRIS"]
const EWALLET_METHODS = ["OVO", "DANA", "LINKAJA", "SHOPEEPAY", "12", "13", "14", "OV", "SA", "LF", "LA", "DA", "SL", "OL", "JP"]
const VA_METHODS = [
  "BRIVA", "BCAVA", "MANDIRIVA", "BNIVA", "PERMATAVA",
  "CIMBVA", "MUAMALATVA", "DANAMONVA", "MAYBANKVA",
  "BSIVA", "SEAABVA", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "21", "22", "BC", "M2", "VA", "I1", "B1", "BT", "A1", "AG", "NC", "BR", "S1", "DM", "BV"
]
const RETAIL_METHODS = ["INDOMARET", "ALFAMART", "ALFAMIDI", "18", "19", "FT", "IR"]

const drawRoundedRect = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.arcTo(x + w, y, x + w, y + h, radius)
  ctx.arcTo(x + w, y + h, x, y + h, radius)
  ctx.arcTo(x, y + h, x, y, radius)
  ctx.arcTo(x, y, x + w, y, radius)
  ctx.closePath()
}

export function InvoicePaymentMethod({
  order,
  handleCopyPayCode,
  handleCopyOrderId,
  handleCopySn,
  getBackgroundPayStatusColor,
  getBackgroundBuyStatusColor,
  getBuyStatusMessage
}: InvoicePaymentMethodProps) {
  const [qrString, setQrString] = useState<string | null>(null)
  const [downloading, setDownloading] = useState(false)
  const qrisSvgWrapRef = useRef<HTMLDivElement | null>(null)

  const isQrispy = useMemo(() => {
    return String(order.payment_method || "").toUpperCase() === "QRISPY"
  }, [order.payment_method])

  const qrispySrc = useMemo(() => {
    if (!isQrispy) return null

    const b64 = String(order.qrispy_image_base64 || "").trim()
    if (b64) {
      if (b64.startsWith("data:image")) return b64
      return `data:image/png;base64,${b64}`
    }

    const url = String(order.qrispy_image_url || "").trim()
    if (url) return url

    const payCode = String(order.payment_code || "").trim()
    if (payCode.startsWith("http://") || payCode.startsWith("https://")) return payCode

    return null
  }, [isQrispy, order.qrispy_image_base64, order.qrispy_image_url, order.payment_code])

  const isQrispyDataUri = useMemo(() => {
    if (!qrispySrc) return false
    return qrispySrc.startsWith("data:image")
  }, [qrispySrc])

  useEffect(() => {
    if (QRIS_STRING_METHODS.includes(order.payment_method) && order.payment_code) {
      setQrString(order.payment_code)
      return
    }
    setQrString(null)
  }, [order.payment_method, order.payment_code])

  const fileName = useMemo(() => {
    const invoice = String(order.order_id || "invoice").trim().replace(/\s+/g, "-")
    return `${invoice}.jpg`
  }, [order.order_id])

  const downloadBlob = async (blob: Blob, name: string) => {
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = name
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  }

  const toJpegBlobFromCanvas = async (canvas: HTMLCanvasElement) => {
    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => {
        if (!b) return reject(new Error("Gagal membuat file"))
        resolve(b)
      }, "image/jpeg", 0.95)
    })
  }

  const downloadQrisFromImage = async (src: string) => {
    const res = await fetch(src, { cache: "no-store" })
    const blob = await res.blob()
    const bitmap = await createImageBitmap(blob)

    const pad = Math.round(Math.max(24, Math.min(bitmap.width, bitmap.height) * 0.08))
    const radius = Math.round(Math.max(14, pad * 0.5))
    const canvas = document.createElement("canvas")
    canvas.width = bitmap.width + pad * 2
    canvas.height = bitmap.height + pad * 2

    const ctx = canvas.getContext("2d")
    if (!ctx) throw new Error("Canvas tidak tersedia")

    ctx.fillStyle = "#ffffff"
    drawRoundedRect(ctx, 0, 0, canvas.width, canvas.height, radius)
    ctx.fill()

    ctx.drawImage(bitmap, pad, pad, bitmap.width, bitmap.height)

    const jpg = await toJpegBlobFromCanvas(canvas)
    await downloadBlob(jpg, fileName)
  }

  const downloadQrisFromSvg = async () => {
    const wrap = qrisSvgWrapRef.current
    const svg = wrap?.querySelector("svg")
    if (!svg) throw new Error("QR belum siap")

    const cloned = svg.cloneNode(true) as SVGSVGElement
    if (!cloned.getAttribute("xmlns")) cloned.setAttribute("xmlns", "http://www.w3.org/2000/svg")

    const serializer = new XMLSerializer()
    const svgString = serializer.serializeToString(cloned)
    const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" })
    const svgUrl = URL.createObjectURL(svgBlob)

    const img = new window.Image()
    img.decoding = "async"

    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve()
      img.onerror = () => reject(new Error("Gagal memuat QR"))
      img.src = svgUrl
    })

    const qrSize = 900
    const pad = 64
    const radius = 28
    const canvas = document.createElement("canvas")
    canvas.width = qrSize + pad * 2
    canvas.height = qrSize + pad * 2

    const ctx = canvas.getContext("2d")
    if (!ctx) {
      URL.revokeObjectURL(svgUrl)
      throw new Error("Canvas tidak tersedia")
    }

    ctx.fillStyle = "#ffffff"
    drawRoundedRect(ctx, 0, 0, canvas.width, canvas.height, radius)
    ctx.fill()

    ctx.imageSmoothingEnabled = false
    ctx.drawImage(img, pad, pad, qrSize, qrSize)

    URL.revokeObjectURL(svgUrl)

    const jpg = await toJpegBlobFromCanvas(canvas)
    await downloadBlob(jpg, fileName)
  }

  const downloadFromDataUri = async (dataUri: string) => {
    const m = dataUri.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/)
    const mime = m?.[1] || "image/png"
    const b64 = m?.[2] || ""
    if (!b64) throw new Error("QR tidak valid")

    const bin = atob(b64)
    const bytes = new Uint8Array(bin.length)
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)

    const blob = new Blob([bytes], { type: mime })
    await downloadBlob(blob, fileName)
  }

  const handleDownloadQris = async () => {
    if (downloading) return
    setDownloading(true)
    try {
      if (order.payment_method === "QRIS" && order.payment_code) {
        await downloadQrisFromImage(order.payment_code)
      } else if (order.payment_method === "SMPQRIS" && qrString) {
        await downloadQrisFromSvg()
      }
    } finally {
      setDownloading(false)
    }
  }

  const handleDownloadQrispy = async () => {
    if (downloading) return
    if (!qrispySrc) return
    setDownloading(true)
    try {
      if (qrispySrc.startsWith("data:image")) {
        await downloadFromDataUri(qrispySrc)
      } else {
        await downloadQrisFromImage(qrispySrc)
      }
    } finally {
      setDownloading(false)
    }
  }

  const showDownloadQris =
    order.payment_status === "UNPAID" &&
    ((order.payment_method === "QRIS" && !!order.payment_code) ||
      (order.payment_method === "SMPQRIS" && !!qrString))

  const showDownloadQrispy = order.payment_status === "UNPAID" && isQrispy && !!qrispySrc

  return (
    <div className="rounded-xl border border-border bg-muted/50 p-4 space-y-4">
      <div>
        <p className="text-sm text-muted-foreground">Metode Pembayaran</p>
        <p className="text-base font-semibold text-foreground">{order.payment_name}</p>
      </div>

      <div className="space-y-4 text-sm">
        <div className="flex flex-col md:flex-row md:items-center gap-2">
          <span className="md:w-1/3 text-muted-foreground">Nomor Invoice</span>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 bg-muted rounded-md font-semibold text-foreground text-sm">{order.order_id}</span>
            <button onClick={handleCopyOrderId} className="p-2 bg-muted rounded-md" type="button">
              <Clipboard className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:items-center gap-2">
          <span className="md:w-1/3 text-muted-foreground">Status Pembayaran</span>
          <span className={`inline-flex rounded-md px-2 py-1 text-xs font-semibold uppercase w-fit ${getBackgroundPayStatusColor()}`}>
            {order.payment_status}
          </span>
        </div>

        <div className="flex flex-col md:flex-row md:items-center gap-2">
          <span className="md:w-1/3 text-muted-foreground">Status Transaksi</span>
          <span className={`inline-flex rounded-md px-2 py-1 text-xs font-semibold uppercase w-fit ${getBackgroundBuyStatusColor()}`}>
            {order.buy_status}
          </span>
        </div>

        {order.serial_number && (
          <div className="flex flex-col md:flex-row md:items-center gap-2">
            <span className="md:w-1/3 text-muted-foreground">Serial Number</span>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 bg-muted rounded-md font-semibold text-foreground text-sm">{order.serial_number}</span>
              <button onClick={handleCopySn} className="p-2 bg-muted rounded-md" type="button">
                <Clipboard className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {order.payment_status === "UNPAID" && (
          <div className="flex flex-col md:flex-row md:items-center gap-2">
            <span className="md:w-1/3 text-muted-foreground">Pesan</span>
            <p className="text-sm font-medium text-foreground">{getBuyStatusMessage()}</p>
          </div>
        )}

        {order.payment_status === "UNPAID" && (
          <div className="flex flex-col gap-3">
            <span className="text-sm font-medium text-muted-foreground">Kode Pembayaran</span>

            {isQrispy ? (
              <div className="flex flex-col items-center gap-2">
                <div className="inline-flex items-center justify-center rounded-lg bg-white p-2 shadow">
                  {qrispySrc ? (
                    isQrispyDataUri ? (
                      <Image
                        src={qrispySrc}
                        alt={String(order.order_id)}
                        width={184}
                        height={184}
                        className="h-46 w-46 object-contain rounded-md"
                        unoptimized
                      />
                    ) : (
                      <Image
                        src={qrispySrc}
                        alt={String(order.order_id)}
                        width={184}
                        height={184}
                        className="h-46 w-46 object-contain rounded-md"
                        priority
                      />
                    )
                  ) : (
                    <div className="h-46 w-46 flex items-center justify-center text-xs text-muted-foreground">
                      QR belum tersedia
                    </div>
                  )}
                </div>

                <p className="text-xs text-center text-muted-foreground">Scan QR Code untuk melakukan pembayaran.</p>

                {showDownloadQrispy ? (
                  <Button
                    type="button"
                    onClick={handleDownloadQrispy}
                    disabled={downloading}
                    className="w-full bg-my-color text-white hover:bg-my-hoverColor"
                  >
                    {downloading ? "Menyiapkan..." : "Download QR"}
                  </Button>
                ) : null}
              </div>
            ) : QRIS_IMAGE_METHODS.includes(order.payment_method) ? (
              <div className="flex flex-col items-center gap-2">
                <div className="inline-flex items-center justify-center rounded-lg bg-white p-2 shadow">
                  <Image
                    src={order.payment_code}
                    alt={String(order.order_id)}
                    width={184}
                    height={184}
                    className="h-46 w-46 object-contain rounded-md"
                  />
                </div>

                <p className="text-xs text-center text-muted-foreground">Scan QR Code untuk melakukan pembayaran.</p>

                {showDownloadQris && order.payment_method === "QRIS" && (
                  <button
                    type="button"
                    onClick={handleDownloadQris}
                    disabled={downloading}
                    className="w-full px-4 py-2 rounded-lg bg-my-color text-white hover:bg-my-hoverColor transition text-sm font-medium disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {downloading ? "Menyiapkan..." : "Download QR"}
                  </button>
                )}
              </div>
            ) : QRIS_STRING_METHODS.includes(order.payment_method) ? (
              <div className="flex flex-col items-center gap-2">
                <div className="inline-flex items-center justify-center rounded-lg bg-white p-2 shadow">
                  <div ref={qrisSvgWrapRef}>
                    {qrString ? <QRCode value={qrString} size={200} /> : "Loading QR..."}
                  </div>
                </div>

                <p className="text-xs text-center text-muted-foreground">Scan QR Code untuk melakukan pembayaran.</p>

                {showDownloadQris && order.payment_method === "SMPQRIS" && (
                  <button
                    type="button"
                    onClick={handleDownloadQris}
                    disabled={downloading}
                    className="w-full px-4 py-2 rounded-lg bg-my-color text-white hover:bg-my-hoverColor transition text-sm font-medium disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {downloading ? "Menyiapkan..." : "Download QR"}
                  </button>
                )}
              </div>
            ) : EWALLET_METHODS.includes(order.payment_method) ? (
              <a
                href={order.payment_code}
                target="_blank"
                rel="noopener noreferrer"
                className="w-fit px-4 py-2 bg-my-color text-white rounded-lg hover:bg-my-hoverColor transition text-sm"
              >
                Bayar Sekarang
              </a>
            ) : VA_METHODS.includes(order.payment_method) ? (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 bg-muted rounded-md font-semibold text-foreground text-sm">{order.payment_code}</span>
                <button onClick={handleCopyPayCode} className="p-2 bg-muted rounded-md" type="button">
                  <Clipboard className="h-4 w-4" />
                </button>
              </div>
            ) : RETAIL_METHODS.includes(order.payment_method) ? (
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1.5 bg-muted rounded-md font-semibold text-foreground text-sm">{order.payment_code}</span>
                  <button onClick={handleCopyPayCode} className="p-2 bg-muted rounded-md" type="button">
                    <Clipboard className="h-4 w-4" />
                  </button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Gunakan kode ini untuk membayar di {order.payment_method === "INDOMARET" ? "Indomaret" : "Alfamart/Alfamidi"}.
                </p>
              </div>
            ) : (
              <p className="text-red-500 font-semibold text-sm">Metode pembayaran tidak dikenali</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
