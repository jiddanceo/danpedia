import Image from "next/image";
import { Transaction } from "@/types";

interface InvoiceGameInfoProps {
  order: Transaction;
  game: any;
}

export function InvoiceGameInfo({ order, game }: InvoiceGameInfoProps) {
  return (
    <div className="flex items-start gap-4 rounded-2xl border border-border bg-muted/50 p-4">
      <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden relative">
        <Image
          alt={game.title}
          src={game.image}
          fill
          className="object-cover object-center"
          sizes="80px"
          style={{ position: "absolute", inset: 0 }}
        />
      </div>
      <div className="flex-1 space-y-2">
        <div>
          <h3 className="text-md font-semibold text-foreground">{order.games}</h3>
          <p className="text-sm text-muted-foreground">{order.product}</p>
        </div>
        <div className="space-y-1 text-sm">
          {order.nickname && (
            <div className="flex text-sm">
              <span className="w-20 text-muted-foreground">Nickname</span>
              <span className="text-foreground">: {order.nickname}</span>
            </div>
          )}
          <div className="flex text-sm">
            <span className="w-20 text-muted-foreground">ID</span>
            <span className="text-foreground">: {order.id_games}</span>
          </div>
          {order.server_games && (
            <div className="flex text-sm">
              <span className="w-20 text-muted-foreground">Server</span>
              <span className="text-foreground">: {order.server_games}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}