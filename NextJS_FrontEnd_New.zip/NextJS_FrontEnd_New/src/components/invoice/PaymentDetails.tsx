import { Transaction } from "@/types";

interface InvoicePaymentDetailsProps {
  order: Transaction;
}

export function InvoicePaymentDetails({ order }: InvoicePaymentDetailsProps) {
  const promoCode = (order as any).promo_code ?? null;
  const promoDiscount = Math.max(0, Number((order as any).promo_discount ?? 0));
  const showPromo = Boolean(promoCode && promoDiscount > 0);

  const fee = Math.max(0, Number(order.fee ?? 0));
  const total = Math.max(0, Number(order.total_price ?? 0));
  const priceAfterPromo = Math.max(0, Number(order.price ?? 0));

  const priceBeforePromo = showPromo ? priceAfterPromo + promoDiscount : priceAfterPromo;

  const paymentMethod = String((order as any).payment_method ?? "");
  const isSmp = paymentMethod.toUpperCase().startsWith("SMP");

  const uniqueCode = Math.max(0, total - priceAfterPromo - fee);
  const showUniqueCode = isSmp && uniqueCode > 0;

  return (
    <div className="rounded-xl border border-border bg-muted/50 p-4 space-y-4 text-sm">
      <div className="space-y-3">
        {showPromo ? (
          <>
            <div className="flex justify-between">
              <span className="text-foreground font-medium">Harga sebelum promo</span>
              <span className="text-muted-foreground">
                Rp {priceBeforePromo.toLocaleString("id-ID")}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-foreground font-medium">Kode Promo</span>
              <span className="text-muted-foreground font-medium">{promoCode}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-foreground font-medium">Diskon promo</span>
              <span className="text-muted-foreground">
                -Rp {promoDiscount.toLocaleString("id-ID")}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-foreground font-medium">Harga sesudah promo</span>
              <span className="text-muted-foreground">
                Rp {priceAfterPromo.toLocaleString("id-ID")}
              </span>
            </div>
          </>
        ) : (
          <div className="flex justify-between">
            <span className="text-foreground font-medium">Harga</span>
            <span className="text-muted-foreground">
              Rp {priceAfterPromo.toLocaleString("id-ID")}
            </span>
          </div>
        )}

        <div className="flex justify-between">
          <span className="text-foreground font-medium">Payment Fee</span>
          <span className="text-muted-foreground">
            Rp {fee.toLocaleString("id-ID")}
          </span>
        </div>

        {showUniqueCode ? (
          <div className="flex justify-between">
            <span className="text-foreground font-medium">Kode Unik Pembayaran</span>
            <span className="font-semibold text-my-color">
              {uniqueCode.toLocaleString("id-ID")}
            </span>
          </div>
        ) : null}
      </div>

      <div className="border-t border-border pt-3 flex justify-between items-center">
        <span className="text-foreground font-semibold">Total Pembayaran</span>
        <span className="text-primary font-bold text-base">
          Rp {total.toLocaleString("id-ID")}
        </span>
      </div>
    </div>
  );
}
