"use client";

import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  TicketPercent,
  Clock,
  Info,
  ShieldCheck,
  Tag,
  CheckCircle2,
} from "lucide-react";

type PromoStatus = "ACTIVE" | "INACTIVE" | "UPCOMING" | "EXPIRED";

interface PromoItem {
  id: number;
  name: string;
  code: string;
  status: PromoStatus;
  is_eligible: boolean;
  discount_type: "PERCENT" | "FLAT";
  discount_value: number;
  min_product_price: number | null;
  start_at: string | null;
  end_at: string | null;
  usage_limit_total: number | null;
  used_count: number;
}

interface PromoValidateResult {
  promo: {
    id: number;
    code: string;
    name: string;
    discount_type: "PERCENT" | "FLAT";
    discount_value: number;
    start_at: string | null;
    end_at: string | null;
    min_product_price: number | null;
  };
  pricing: {
    base_price: number;
    discount: number;
    final_price: number;
  };
}

interface PromoCodeSectionProps {
  gameSlug: string | null;
  productId: string | null;
  paymentMethodId: string | null;
  whatsapp: string;
  onApplied: (payload: { code: string; discount: number; finalPrice: number }) => void;
  onCleared: () => void;
  appliedCode: string | null;
  appliedDiscount: number;
}

const fmtRupiah = (n: number) => `Rp ${Math.max(0, Math.floor(n)).toLocaleString("id-ID")}`;

const fmtDateShort = (iso: string | null) => {
  if (!iso) return "-";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "numeric" });
};

const discountLabelTitle = (type: "PERCENT" | "FLAT", value: number) => {
  if (type === "PERCENT") return `Diskon hingga ${Math.min(100, Math.max(1, Math.floor(value)))}%`;
  return `Diskon ${fmtRupiah(value)}`;
};

const discountLabel = (type: "PERCENT" | "FLAT", value: number) => {
  if (type === "PERCENT") return `${Math.min(100, Math.max(1, Math.floor(value)))}%`;
  return fmtRupiah(value);
};

const getUnavailableLabel = (p: PromoItem) => {
  if (p.status === "EXPIRED") return "Tidak Tersedia";
  if (p.status === "UPCOMING") return "Belum Berlaku";
  if (p.status === "INACTIVE") return "Tidak Aktif";
  if (!p.is_eligible) return "Tidak Tersedia";
  if (p.usage_limit_total !== null && p.used_count >= p.usage_limit_total) return "Habis";
  return "Tidak Tersedia";
};

export default function PromoCodeSection({
  gameSlug,
  productId,
  paymentMethodId,
  whatsapp,
  onApplied,
  onCleared,
  appliedCode,
  appliedDiscount,
}: PromoCodeSectionProps) {
  const [code, setCode] = useState("");
  const [isApplying, setIsApplying] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [isLoadingList, setIsLoadingList] = useState(false);
  const [list, setList] = useState<PromoItem[]>([]);

  useEffect(() => {
    if (appliedCode) setCode(appliedCode);
  }, [appliedCode]);

  const canApply = useMemo(() => {
    return Boolean(gameSlug && productId && paymentMethodId && code.trim().length > 0);
  }, [gameSlug, productId, paymentMethodId, code]);

  const applyPromo = async (inputCode?: string) => {
    if (!gameSlug || !productId || !paymentMethodId) {
      toast.error("Silakan pilih produk dan metode pembayaran terlebih dahulu.");
      return;
    }

    const c = (inputCode ?? code).trim();
    if (!c) return;

    setIsApplying(true);
    try {
      const res = await fetch("/api/promo-codes/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: c,
          game: gameSlug,
          product_id: productId,
          payment_method_id: paymentMethodId,
          whatsapp: whatsapp || null,
        }),
      });

      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.success) {
        toast.error(json?.message ?? "Kode promo tidak valid.");
        return;
      }

      const data: PromoValidateResult | undefined = json?.data;
      const promoCode = data?.promo?.code;
      const discount = data?.pricing?.discount ?? 0;
      const finalPrice = data?.pricing?.final_price;

      if (!promoCode || typeof finalPrice !== "number") {
        toast.error("Response promo tidak valid.");
        return;
      }

      setCode(promoCode);
      onApplied({
        code: promoCode,
        discount: Math.max(0, Math.floor(discount)),
        finalPrice: Math.max(0, Math.floor(finalPrice)),
      });
      toast.success("Kode promo berhasil digunakan.");
    } finally {
      setIsApplying(false);
    }
  };

  const loadList = async () => {
    if (!gameSlug || !productId || !paymentMethodId) {
      toast.error("Pilih produk dan metode pembayaran terlebih dahulu.");
      return;
    }

    setIsLoadingList(true);
    try {
      const url = new URL("/api/promo-codes", window.location.origin);
      url.searchParams.set("game", gameSlug);
      url.searchParams.set("product_id", productId);
      url.searchParams.set("payment_method_id", paymentMethodId);
      const res = await fetch(url.toString(), { cache: "no-store" });
      const json = await res.json().catch(() => null);

      if (!res.ok || !json?.success) {
        toast.error(json?.message ?? "Gagal memuat promo.");
        return;
      }

      setList(Array.isArray(json?.data) ? json.data : []);
      setDialogOpen(true);
    } finally {
      setIsLoadingList(false);
    }
  };

  const pickPromo = async (p: PromoItem) => {
    const disabled =
      !(p.status === "ACTIVE" && p.is_eligible) ||
      (p.usage_limit_total !== null && p.used_count >= p.usage_limit_total);

    if (disabled) return;
    setDialogOpen(false);
    await applyPromo(p.code);
  };

  return (
    <section
      id="4"
      className="relative scroll-mt-20 rounded-xl bg-background shadow-sm ring-1 ring-border md:scroll-mt-[7.5rem]"
    >
      <div className="flex items-center rounded-t-xl bg-muted px-4 py-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-my-color font-semibold text-white">
          4
        </div>
        <h2 className="ml-3 text-sm font-semibold text-card-foreground">
          Kode Promo (Jika Ada)
        </h2>
      </div>

      <div className="p-4 space-y-3">
        <div className="flex items-stretch gap-2">
          <div className="relative flex-1">
            <Tag className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="Masukkan kode promo"
              className="w-full rounded-lg border border-border bg-muted pl-10 pr-3 py-2.5 text-xs text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-my-color"
              maxLength={64}
              inputMode="text"
              autoComplete="off"
            />
          </div>

          <button
            type="button"
            onClick={() => applyPromo()}
            disabled={!canApply || isApplying}
            className="h-9 shrink-0 px-2.5 rounded-lg bg-my-color text-[11px] font-semibold text-white transition disabled:cursor-not-allowed disabled:opacity-60 hover:bg-my-hoverColor inline-flex items-center justify-center"
          >
            <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
            {isApplying ? "Proses" : "Gunakan"}
          </button>
        </div>

        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={loadList}
            disabled={isLoadingList}
            className="h-8 px-3 rounded-lg border border-border bg-muted text-xs font-medium text-foreground transition hover:bg-muted/80 disabled:opacity-60 inline-flex items-center"
          >
            <TicketPercent className="h-4 w-4 mr-2" />
            {isLoadingList ? "Memuat" : "Lihat Kode Promo"}
          </button>

          {appliedCode ? (
            <button
              type="button"
              onClick={() => {
                setCode("");
                onCleared();
              }}
              className="text-xs font-medium text-destructive hover:underline"
            >
              Hapus promo
            </button>
          ) : null}
        </div>

        {appliedCode ? (
          <div className="rounded-lg border border-border bg-muted/40 p-3 text-xs text-foreground">
            <div className="flex items-center justify-between">
              <span className="font-semibold">{appliedCode}</span>
              <span className="font-semibold">-{fmtRupiah(appliedDiscount)}</span>
            </div>
          </div>
        ) : null}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Promo yang tersedia</DialogTitle>
          </DialogHeader>

          <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
            {list.length ? (
              list.map((p) => {
                const soldOut =
                  p.usage_limit_total !== null && p.used_count >= p.usage_limit_total;
                const disabled = !(p.status === "ACTIVE" && p.is_eligible) || soldOut;
                const untilDate = p.end_at ? fmtDateShort(p.end_at) : null;

                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => pickPromo(p)}
                    disabled={disabled}
                    className={`w-full text-left rounded-2xl border border-border bg-muted/40 p-5 transition ${
                      disabled
                        ? "opacity-60 cursor-not-allowed"
                        : "hover:ring-2 hover:ring-my-color"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-2">
                        <div className="text-base font-semibold text-my-color">
                          {discountLabelTitle(p.discount_type, p.discount_value)}
                        </div>

                        <div className="space-y-1 text-xs text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            <span>
                              {untilDate
                                ? `Promo berlaku hingga ${untilDate}`
                                : "Periode promo mengikuti ketentuan."}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Info className="h-4 w-4" />
                            <span>
                              {p.min_product_price !== null
                                ? `Minimum pembelian ${fmtRupiah(p.min_product_price)}`
                                : "Tidak ada minimum pembelian"}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <ShieldCheck className="h-4 w-4" />
                            <span>
                              {p.usage_limit_total !== null
                                ? `Batas penggunaan ${p.usage_limit_total} kali (tersisa ${Math.max(
                                    0,
                                    p.usage_limit_total - p.used_count
                                  )})`
                                : "Tanpa batas kuota global"}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <Info className="h-4 w-4" />
                            <span>
                              Promo ini mengikuti ketentuan game dan metode pembayaran
                              yang dipilih.
                            </span>
                          </div>
                        </div>

                        <div className="pt-2 text-sm">
                          <span className="text-muted-foreground">Kode Promo: </span>
                          <span className="font-semibold text-my-color">{p.code}</span>
                        </div>
                      </div>

                      <div className="shrink-0">
                        {disabled ? (
                          <span className="inline-flex items-center rounded-full bg-destructive/20 px-4 py-2 text-xs font-semibold text-destructive">
                            {soldOut ? "Habis" : getUnavailableLabel(p)}
                          </span>
                        ) : (
                          <span className="inline-flex items-center rounded-full bg-my-color/15 px-4 py-2 text-xs font-semibold text-my-color">
                            {discountLabel(p.discount_type, p.discount_value)}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="rounded-xl border border-dashed p-6 text-sm text-muted-foreground text-center">
                Tidak ada promo tersedia.
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}