"use client";

import { createContext, useContext, useState, useEffect } from "react";

interface Settings {
  success: boolean;
  data: {
    general?: {
      title?: string;
      logo?: string;
      favicon?: string;
    };
    seo?: {
      title?: string;
      description?: string;
      keywords?: string;
    };
    sosmed?: {
      fb?: string;
      ig?: string;
      wa?: string;
    };
  };
}

const SettingsContext = createContext<Settings>({
  success: false,
  data: {},
});

export const useSettings = () => {
  return useContext(SettingsContext);
};

export const SettingsProvider = ({ children }: { children: React.ReactNode }) => {
  const [settings, setSettings] = useState<Settings>({
    success: false,
    data: {},
  });

  useEffect(() => {
    async function fetchSettings() {
      try {
        const res = await fetch("/api/settings");
  
        if (!res.ok) throw new Error("Gagal memuat settings");
  
        const data = await res.json();
        setSettings({
          success: data.success,
          data: data.data || {},
        });
      } catch (error) {
        console.error("Gagal memuat settings:", error);
      }
    }
  
    fetchSettings();
  }, []);

  return <SettingsContext.Provider value={settings}>{children}</SettingsContext.Provider>;
};