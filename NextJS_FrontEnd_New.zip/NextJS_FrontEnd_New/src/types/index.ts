export interface CategoryObj {
  id: number
  title: string
  logo: string | null
  game: string
}

export interface Product {
  id: string
  title: string
  images?: string
  logo?: string
  category?: CategoryObj | null
  selling_price: number
  selling_price_gold: number
  selling_price_platinum: number
  promo_price?: number | null
}

export type PaymentMethod = {
  id: string
  name: string
  images: string
  payment_id: string
  minimum_amount: number
  maximum_amount: number
  fee: number
  fee_percent: number
  totalPrice: number
  type: string
  status: string
  group: string
  is_outside_group?: boolean
  badge_text?: string | null
  outside_sort?: number
}

type PaymentInstruction = {
  title: string
  steps: string[]
}

export interface Transaction {
  order_id: string
  games: string
  product: string
  id_games: string
  server_games?: string | null
  nickname?: string | null
  price: number
  fee: number
  discount_price?: number | null
  promo_price: number
  total_price: number
  payment_name: string
  payment_method: string
  payment_code: string
  payment_status: string
  payment_instructions?: PaymentInstruction[]
  buy_status: string
  serial_number: string
  expired_time: number
  created_at: string

  qrispy_qris_id?: string | null
  qrispy_image_url?: string | null
  qrispy_image_base64?: string | null
  qrispy_expires_at?: string | null
  qrispy_paid_at?: string | null
}

export type SummaryData = {
  total: number
  pending: number
  proses: number
  sukses: number
  gagal: number
} & Record<string, number>
