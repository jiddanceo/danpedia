<!DOCTYPE html>
<html>
<head>
    <title>Pesanan Anda Telah Diterima</title>
</head>
<body>
    <h2>Halo, Terima kasih telah melakukan pemesanan di {{ config('app.name') }}!</h2>
    <p>Detail pesanan Anda:</p>

    <ul>
        <li><strong>Order ID:</strong> {{ $order['order_id'] }}</li>
        <li><strong>Game:</strong> {{ $order['games'] }}</li>
        <li><strong>Produk:</strong> {{ $order['product'] }}</li>
        <li><strong>Harga:</strong> Rp{{ number_format($order['price'], 0, ',', '.') }}</li>
        <li><strong>Metode Pembayaran:</strong> {{ $order['payment_name'] }}</li>
        <li><strong>Status Pembayaran:</strong> {{ $order['payment_status'] }}</li>
        <li><strong>Status Pembelian:</strong> {{ $order['buy_status'] }}</li>
        <li><strong>Batas Pembayaran:</strong> {{ date('d M Y H:i', $order['expired_time']) }}</li>
    </ul>

    <p>Silakan selesaikan pembayaran sebelum batas waktu yang ditentukan.</p>

    <p><strong>Lihat detail pesanan Anda:</strong></p>
    <p>
        <a href="{{ config('app.front_url') }}/invoices/{{ $order['order_id'] }}" 
           style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">
            Lihat Invoice
        </a>
    </p>

    <p>Terimakasih!</p>
</body>
</html>