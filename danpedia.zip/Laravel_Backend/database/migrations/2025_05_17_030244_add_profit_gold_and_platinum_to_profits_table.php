<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('profits', function (Blueprint $table) {
            $table->decimal('profit_gold_percentage', 5, 2)->nullable()->after('profit_percentage');
            $table->decimal('profit_platinum_percentage', 5, 2)->nullable()->after('profit_gold_percentage');
        });
    }

    public function down(): void
    {
        Schema::table('profits', function (Blueprint $table) {
            $table->dropColumn(['profit_gold_percentage', 'profit_platinum_percentage']);
        });
    }
};
