<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('game_configurations', function (Blueprint $table) {
            $table->json('input_fields')->nullable()->after('required_inputs');
        });
    }

    public function down(): void
    {
        Schema::table('game_configurations', function (Blueprint $table) {
            $table->dropColumn('input_fields');
        });
    }
};
