<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeFeePercentTypeInPaymentMethodsTable extends Migration
{
    public function up()
    {
        Schema::table('payment_methods', function (Blueprint $table) {
            $table->decimal('fee_percent', 5, 2)->change();
        });
    }

    public function down()
    {
        Schema::table('payment_methods', function (Blueprint $table) {
            // Ubah sesuai tipe sebelumnya, misalnya integer
            $table->unsignedBigInteger('fee_percent')->change();
        });
    }
}
