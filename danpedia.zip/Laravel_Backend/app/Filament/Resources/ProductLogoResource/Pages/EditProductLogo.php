<?php

namespace App\Filament\Resources\ProductLogoResource\Pages;

use App\Filament\Resources\ProductLogoResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditProductLogo extends EditRecord
{
    protected static string $resource = ProductLogoResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
