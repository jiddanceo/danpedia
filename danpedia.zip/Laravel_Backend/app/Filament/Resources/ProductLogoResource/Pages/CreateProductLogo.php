<?php

namespace App\Filament\Resources\ProductLogoResource\Pages;

use App\Filament\Resources\ProductLogoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProductLogo extends CreateRecord
{
    protected static string $resource = ProductLogoResource::class;
}
