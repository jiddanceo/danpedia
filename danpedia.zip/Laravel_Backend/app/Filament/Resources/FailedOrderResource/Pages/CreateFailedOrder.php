<?php

namespace App\Filament\Resources\FailedOrderResource\Pages;

use App\Filament\Resources\FailedOrderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFailedOrder extends CreateRecord
{
    protected static string $resource = FailedOrderResource::class;
}
