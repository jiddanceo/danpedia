<?php

namespace App\Filament\Resources\FailedOrderResource\Pages;

use App\Filament\Resources\FailedOrderResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListFailedOrders extends ListRecords
{
    protected static string $resource = FailedOrderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
