<?php

namespace App\Providers\Filament;

use Outerweb\FilamentSettings\Filament\Plugins\FilamentSettingsPlugin;
use Filament\PanelProviders\PanelProvider;
use Filament\Panel;

class FilamentPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->plugins([
                FilamentSettingsPlugin::make()
                    ->pages([
                        \App\Filament\Pages\Settings\Settings::class,
                        \App\Filament\Pages\ApiSettings\ApiSettings::class,
                    ])
            ])
            ->pages([

            ]);
    }
}