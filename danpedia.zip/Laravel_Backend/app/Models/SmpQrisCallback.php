<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmpQrisCallback extends Model
{
    protected $fillable = [
        'rrn',
        'us_username',
        'tr_id',
        'issuer',
        'payer_name',
        'amount_value',
        'saldo_akhir',
        'timestamp',
        'matched_order_id',
        'qris_payment_id',
        'payload',
    ];

    protected $casts = [
        'payload' => 'array',
        'timestamp' => 'datetime',
    ];
}