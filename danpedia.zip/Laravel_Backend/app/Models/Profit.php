<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Profit extends Model {
    protected $fillable = [
      'game_id',
      'profit_percentage',
      'profit_gold_percentage',
      'profit_platinum_percentage'
    ];

    public function game() {
        return $this->belongsTo(Game::class);
    }
}