<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    use HasFactory;

    protected $fillable = [
        'code_account',
        'email',
        'password',
        'email_recovery',
        'password_recovery',
        'link_webmail',
        'descriptions',
        'stok',
        'status',
    ];
}