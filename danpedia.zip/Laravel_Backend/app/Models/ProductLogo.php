<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProductLogo extends Model
{
    use HasFactory;

    protected $fillable = ['brand', 'image'];

    public function products()
    {
        return $this->hasMany(Product::class, 'brand', 'brand');
    }
}