<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OtpCode extends Model
{
    protected $table = 'otp_codes';

    protected $fillable = [
        'whatsapp',
        'purpose',
        'otp_hash',
        'expires_at',
        'resend_available_at',
        'attempts',
        'max_attempts',
        'ip',
        'user_agent',
        'consumed_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'resend_available_at' => 'datetime',
        'consumed_at' => 'datetime',
    ];
}