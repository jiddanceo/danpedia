<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsappPasswordResetToken extends Model
{
    protected $table = 'whatsapp_password_reset_tokens';

    protected $fillable = [
        'whatsapp',
        'token_hash',
        'expires_at',
        'consumed_at',
        'ip',
        'user_agent',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'consumed_at' => 'datetime',
    ];
}