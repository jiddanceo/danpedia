<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('cek:expire')->everyMinute();
Schedule::command('digiflazz:sync-pending --limit=200')->everyMinute();
Schedule::command('product:fetch-product')->hourly();