<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SmpQrisCallbackController;

Route::match(['GET', 'POST'], '/callbackqris/{secret}', [SmpQrisCallbackController::class, 'handle'])
    ->withoutMiddleware([
        \Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class,
    ]);